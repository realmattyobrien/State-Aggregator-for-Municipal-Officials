# State Aggregator for Municipal Officials

Operational intelligence system for Massachusetts municipal officials. Monitors state legislation and agency guidance, translating it into clear, actionable operational impact analysis.

## Purpose

Reduce risk, cognitive load, and uncertainty for municipal officials by providing role-specific, action-oriented interpretation of state actions. **Clarity, accuracy, and trust over completeness or speed.**

## What It Does

- Monitors MA Legislature bills for significant actions
- Extracts bill history and identifies new developments
- Analyzes operational impact for municipal government
- Generates plain-English briefs for town managers, clerks, finance directors, etc.
- Deduplicates using SHA-256 hashing
- Filters noise by only analyzing significant legislative actions

## Architecture

**Backend (this repository):**
- Express.js API server
- Web scraping with JSDOM
- Anthropic Claude API for analysis
- In-memory storage (upgradeable to PostgreSQL)

**Data Flow:**
1. Fetch bill pages from malegislature.gov
2. Parse HTML to extract action history
3. Generate stable IDs and check for duplicates
4. Filter by trigger words (referrals, hearings, enactments)
5. Analyze with Claude for operational impact
6. Store and serve via API

## Quick Start

### Prerequisites

- Node.js 18+ 
- Anthropic API key (https://console.anthropic.com/)

### Installation

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# Start server
npm start
```

Server runs on `http://localhost:3001`

### Test It

```bash
# In a new terminal
npm test
```

This will:
- Fetch real MA Legislature bills
- Analyze recent actions
- Create impact briefs
- Display results

## API Endpoints

### `POST /api/collect`
Collect and analyze bill data

**Request:**
```json
{
  "billNumbers": ["H3121", "S2024"]
}
```

**Response:**
```json
{
  "success": true,
  "billsProcessed": 2,
  "itemsIdentified": 5,
  "briefsCreated": 3,
  "errors": [],
  "briefs": [...],
  "logs": [...]
}
```

### `GET /api/briefs`
Get all briefs (sorted by date, newest first)

### `GET /api/briefs/:id`
Get single brief by ID

### `GET /health`
Health check endpoint

## Data Schema

Follows `ImpactBriefV1` schema with:
- **Item metadata:** Source, type, title, URL, publication date
- **Bill information:** Number, session, status
- **Analysis:** Summary, implications, roles, actions, urgency, confidence
- **Citations:** Source references

## Trigger Actions

Only analyzes actions matching these keywords:
- "referred to" (committee referrals)
- "committee recommends"
- "reported favorably"
- "public hearing"
- "passed to be engrossed"
- "enacted"
- "governor signed"

## Deduplication

**Item ID:** `SHA-256(billNumber:date:action)` → first 16 chars
**Content Hash:** SHA-256 of action text
**Logic:** Only reprocess if hash changes

## Deployment

### Railway (Recommended for Beginners)

1. Push code to GitHub
2. Go to railway.app
3. Click "New Project" → "Deploy from GitHub"
4. Select this repository
5. Add environment variable: `ANTHROPIC_API_KEY`
6. Deploy!

Railway automatically:
- Installs dependencies
- Starts the server
- Provides a public URL
- Restarts on code changes

### Other Options

- **Heroku:** Add `Procfile` with `web: node server.js`
- **DigitalOcean App Platform:** Works out of the box
- **AWS:** Use Elastic Beanstalk or Lambda
- **Your Computer:** Just run `npm start`

## Adding Daily Automation

### Railway Cron Job

1. In Railway, click "New" → "Cron Job"
2. Schedule: `0 6 * * *` (6am daily)
3. Command: `node scripts/daily-collection.js`

Create `scripts/daily-collection.js`:
```javascript
// Calls your API to collect predefined bills
const bills = ['H3121', 'H3456', 'S2024', 'S2789'];
// POST to /api/collect
// Email results or save to database
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | Yes | Your Anthropic API key |
| `PORT` | No | Server port (default: 3001) |
| `CORS_ORIGIN` | No | Allowed CORS origin |

## Logging

All logs output as structured JSON:

```json
{
  "timestamp": "2025-01-13T10:30:00.000Z",
  "level": "info",
  "message": "Collection started",
  "data": { "billCount": 3 }
}
```

Levels: `info`, `error`, `debug`

## Error Handling

- Individual bill failures don't stop collection
- Each error logged with context
- Returns partial results if some bills succeed
- HTTP errors include status codes and messages

## Extending the System

### Add New Data Source

1. Create collector function in `server.js`:
```javascript
async function collectFromDLS() {
  // Fetch DLS bulletins
  // Parse and return items
}
```

2. Add to `/api/collect` endpoint
3. Update documentation

### Add Database

Replace in-memory storage:

```javascript
// Install pg: npm install pg
import pg from 'pg';
const db = new pg.Pool({ connectionString: process.env.DATABASE_URL });

// In createBrief():
await db.query(
  'INSERT INTO briefs (id, data) VALUES ($1, $2)',
  [brief.brief_id, JSON.stringify(brief)]
);
```

Railway provides PostgreSQL: Click "New" → "Database" → "PostgreSQL"

## Cost Estimates

**Development:** Free (your time)
**Hosting:** $5-20/month (Railway/Heroku)
**Anthropic API:** $50-100/month (depends on usage)
**Total:** ~$55-120/month

## Roadmap

- [ ] PostgreSQL database integration
- [ ] Daily automated collection
- [ ] Email/Slack notifications
- [ ] Web interface (React)
- [ ] Additional sources (DLS, DOR, SEC, OCPF, AG)
- [ ] Role-based filtering
- [ ] Multi-municipality support
- [ ] Historical tracking and trends

## Security

- API key stored in environment (never committed)
- CORS configured for security
- Input validation on all endpoints
- Structured logging for audit trails

## Support

For issues or questions:
1. Check error logs (Railway → Deployments → Logs)
2. Review this README
3. Check malegislature.gov is accessible
4. Verify API key is correct
5. Test with known bill numbers (e.g., H1, S1)

## License

MIT

## Credits

Built for Massachusetts municipal officials to stay informed about state actions affecting local government operations.
